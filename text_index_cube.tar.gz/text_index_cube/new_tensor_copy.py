#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  9 18:32:31 2018

@author: rohit
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 20 14:39:13 2018

@author: rohit
"""
import os
import csv
import time
import email
import numpy as np
import pandas as pd
import tensorflow as tf
from collections import Counter
from nltk.corpus import stopwords
from test_sql import convert_to_table
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from tensorflow.contrib.tensorboard.plugins import projector


def function(fname):
    root = os.getcwd()
    filename = os.path.join(root,fname)
    doc = open(filename, encoding = 'latin-1').read()
    b = email.message_from_string(doc)
    if b.is_multipart():
        for payload in b.get_payload():
            # if payload.is_multipart(): ...
            data = payload.get_payload()
    else:
        data = b.get_payload()

    stop_words = set(stopwords.words('english'))
    lem = WordNetLemmatizer()
    data = [word.lower() for word in word_tokenize(data) if word.isalpha() and word not in stop_words]
    data = [lem.lemmatize(w) for w in data]
    data = [lem.lemmatize(w, 'v') for w in data]
    
    return fname, data

def create_tensor(filename):
    fname, data = function(filename)
    word_pair = []
    data.insert(0, tags[0])
    data.insert(len(data), tags[1])
    
    m = data[1:]
    for x,y in zip(data,m):
        word_pair.append((x,y))
    
    #print(word_pair)
    p = dict(Counter(word_pair))
    a = []
    b = []
    c = []
    for item in p.items():
        a.append(unique_words.index(item[0][0]))
        b.append(unique_words.index(item[0][1]))
        c.append(item[1])
    
    a = tf.convert_to_tensor(a)
    b = tf.convert_to_tensor(b)
    c = tf.convert_to_tensor(c)
    d = [unique_docs.index(fname)]*a.shape[0]
    d = tf.convert_to_tensor(d)
    f = tf.stack([d,a,b,c], 1)
    return f

def merge(list1, size):
    if (size == 0):
        return 0
    elif (size == 1):
        return list1[0]

    #divide and conquer
    mid = int(size / 2)
    rsize = size - mid
    lsum = merge(list1[:mid], mid)
    rsum = merge(list1[mid:], rsize)
    return tf.concat([lsum,rsum], 0)


def bag_of_words(path):
    words = []
    docs = []
    os.chdir(path)
    for folder in os.listdir():
        os.chdir(path+'/'+folder)
        for filename in os.listdir(os.getcwd()):
            print('processing', folder, filename)
            #docs list used for documets identifier
            docs.append(filename)
            fname, data = function(filename)
            words.extend(data)
            
    doc_bag = list(set(docs))
    #word_bag list used for documets identifier
    word_bag = list(set(words))
    #print(len(set(word_bag)))
    return word_bag, doc_bag

def projection(csv_file):  
    LOG_DIR = 'logs'
    metadata = os.path.join(LOG_DIR, 'metadata.tsv')
    data = pd.read_csv("v.csv", sep='\t',header = None)  
    text= tf.Variable(data.iloc[0:,:3], name='text')
    t = time.time()
    f=open(csv_file,'r') # open the csv data file
    reader = csv.reader(f, delimiter = '\t')
    with open(metadata, 'w+') as metadata_file:
        writer = csv.writer((metadata_file), delimiter=',', lineterminator='\n')
        for row in reader:
            row = [unique_docs[int(row[0])], unique_words[int(row[1])], unique_words[int(row[2])], int(row[3])]
            writer.writerow(row)
             
    print(time.time()-t)
    with tf.Session() as sess:
        saver = tf.train.Saver([text])
    
        sess.run(text.initializer)
        saver.save(sess, os.path.join(LOG_DIR, 'text.ckpt'))
    
        config = projector.ProjectorConfig()
        # One can add multiple embeddings.
        embedding = config.embeddings.add()
        embedding.tensor_name = text.name
        # Link this tensor to its metadata file (e.g. labels).
        embedding.metadata_path = 'metadata.tsv'
        # Saves a config file that TensorBoard will read during startup.
        projector.visualize_embeddings(tf.summary.FileWriter(LOG_DIR), config)




#Execution starts here
start_time = time.time()
path = '/home/rohit/Downloads/20_newsgroups3'
#tensor = tf.Variable(tf.zeros([1,4]))
#global_tensor = tf.cast(tensor, tf.int32)
arr = tf.TensorArray(size = 1, dynamic_size = True, dtype=tf.int32, infer_shape = False)
file_count = 0
#Creating BagOfWords
unique_words, unique_docs = bag_of_words(path)
tags = ['START', 'EOD']
unique_words.insert(0, tags[0])
unique_words.insert(len(unique_words), tags[1])
#print(unique_words)

#Creating tensor 
folder_number = 0

os.chdir(path)
for folder in os.listdir():
    os.chdir(path+'/'+folder)
    folder_number += 1
    doc_count = 0
    for filename in os.listdir(os.getcwd()):
        print(len(os.listdir(os.getcwd()))-doc_count,'files remaining from folder', folder_number)
        f = create_tensor(filename)
        arr = arr.write(file_count,f)
        file_count += 1
        #global_tensor = tf.concat([global_tensor,f], 0)
        doc_count += 1

list1 = []
for i in range(file_count):
    list1.append(arr.read(i))

global_tensor = merge(list1, file_count)

tensor_creation_time = (time.time() - start_time)
print('_______________________________________')
print('\n\n%30s %.3f seconds' % ('tensor creation time:', tensor_creation_time))

#creating csv from tensors
csv_start_time = time.time()
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    t = sess.run(global_tensor)

os.chdir('/home/rohit/Downloads/')
with open('v.csv', 'w+') as f:
    np.savetxt(f, t[1:,:], fmt='%d\t%d\t%d\t%d', delimiter = '\t')
print('%30s %.3f seconds' % ('csv creation time:', (time.time() - csv_start_time)))

#projection on tensorboard
tensor_project_time = time.time()
projection("v.csv")
print('%30s %.3f seconds' % ('tensor project time:', (time.time() - tensor_project_time)))

#sqlite conversion
table_start_time = time.time()           
df1 = convert_to_table('v.csv', unique_words, unique_docs)
print('%30s %.3f seconds' % ('table conversion time:', (time.time() - table_start_time)))

print('%30s %.3f seconds' % ('total time taken:', (time.time()-start_time)))
print('\n\nCompleted')