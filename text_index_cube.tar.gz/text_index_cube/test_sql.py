#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug  5 19:44:11 2018

@author: rohit
"""

import csv
import sqlite3
import pandas as pd

def convert_to_table(csv_file, unique_words, unique_docs):
    f=open(csv_file,'r') # open the csv data file
    #next(f, None) # skip the header row
    reader = csv.reader(f, delimiter = '\t')
    
    sql = sqlite3.connect('example2.db')
    cur = sql.cursor()
    
    cur.execute('''CREATE TABLE IF NOT EXISTS t6 (doc text, first_word text, second_word text, count text)''') # create the table if it doesn't already exist
    cur.execute("delete from t6")	 
    for row in reader:
        row = [unique_docs[int(row[0])], unique_words[int(row[1])], unique_words[int(row[2])], int(row[3])]
        cur.execute("INSERT INTO t6 VALUES (?, ?, ?, ?)", row)
    
    #cur.execute('select * from t3')
    #rows = cur.fetchall()
    #for row in rows:
    #    print(row)
    df = pd.read_sql_query('select * from t6', sql)
    #print(df.head())
    f.close()
    sql.commit()
    sql.close()
    return df